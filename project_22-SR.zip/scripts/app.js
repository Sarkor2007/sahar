console.log('Welcome!');

const langBtn = document.querySelector('.header__lang-btn');
const langMenu = document.querySelector('.header__lang-list');
const footerLangBtn = document.querySelector('.footer__lang-btn');
const footerLangMenu = document.querySelector('.footer__lang-list');


langBtn.addEventListener('click', () => {
    langMenu.classList.toggle('active');
})

footerLangBtn.addEventListener('click', () => {
    footerLangMenu.classList.toggle('active');
})

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
});


var swiper = new Swiper(".mySwiperOne", {
    slidesPerView: 1,
    spaceBetween: 15,
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    breakpoints: {
        401: {
            slidesPerView: 1,
            spaceBetween: 20,
        },
    },
});


var swiper = new Swiper(".mySwiperThree", {
    slidesPerView: 3,
    direction: "vertical",
});


const accordionBtn = document.querySelectorAll('.questions__item-btn');
const accordionBody = document.querySelectorAll('.questions__item-content');
const accordionArrow = document.querySelectorAll('.questions__item-btn img');

for (let i = 0; i < accordionBtn.length; i++) {
    accordionBtn[i]?.addEventListener('click', () => {
        accordionBody[i].classList.toggle('active');
        accordionArrow[i].classList.toggle('active');
        if (accordionBody[i].classList.contains('active')) {
            accordionBody[i].style.minHeight = accordionBody[i].scrollHeight + 'px';
        } else {
            accordionBody[i].style.minHeight = '0';
        }
    });
}


const questionsSlider = document.querySelector('.mySwiperTwo');

// questionsSlider.addEventListener('click', () => {
//     for (let i = 0; i < accordionBody.length; i++) {
//         if (accordionBody[i].classList.contains('active')) {
//             accordionBody[i].classList.remove('active');
//             accordionArrow[i].classList.remove('active');
//             accordionBody[i].style.minHeight = '0';
//         }
//     }
// })



// let isActive

// closeAllAccordions();
// for (let i = 0; i < accordionBody.length; i++) {
//     accordionBody[i].classList.contains('active');
//     isActive = accordionBody[i].classList.contains('active');
// }

// questionsSlider.addEventListener('click', () => {
//     console.log(isActive);


//   else {
//         closeAllAccordions();
//     }
// accordionBtn[i]?.addEventListener('click', () => {
//     // Закрываем все открытые аккордеоны
//     if (!isActive) {

//     }

//     console.log(isActive);
// })
// });

// function closeAllAccordions() {
//     for (let i = 0; i < accordionBody.length; i++) {
//         if (accordionBody[i].classList.contains('active')) {
//             accordionBody[i].classList.remove('active');
//             accordionArrow[i].classList.remove('active');
//             accordionBody[i].style.minHeight = '0';
//         }
//     }
// }

var swiper1 = new Swiper(".mySwiperTwo", {
    slidesPerView: 1,
    spaceBetween: 8,
    breakpoints: {
        450: {
            slidesPerView: 1.5,
            spaceBetween: 15,
        },
        576: {
            slidesPerView: 1,
            spaceBetween: 20,
        },
        640: {
            slidesPerView: 1.5,
            spaceBetween: 20,
        },
        870: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        1000: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
    },
});



// const questionsSliderWrapper = document.querySelector('.swiper-wrapper');
// const questionsSliderTitle = document.querySelectorAll('.questions__item-title')[0].scrollHeight

// let result = []
// let height = 0

// for (let i = 0; i < accordionBody.length; i++) {
//     result.push(accordionBody[i].scrollHeight);
// }

// height += (result.sort((a, b) => a - b)[result.length - 1] + questionsSliderTitle)

// console.log(height);


// questionsSlider.style.minHeight = height + 'px';
// questionsSliderWrapper.style.minHeight = height + 'px';




const burgerOpen = document.querySelector('.nav__open');
const burgerExit = document.querySelector('.nav__exit-btn');
const nav = document.querySelector('.nav');
const body = document.querySelector('body')
const filter = document.querySelector('.filter')

burgerOpen.addEventListener('click', () => {
    nav.classList.add('active');
    body.classList.add('active');
    filter.classList.add('active');
})

burgerExit.addEventListener('click', () => {
    nav.classList.remove('active');
    body.classList.remove('active');
    filter.classList.remove('active');
})

filter.addEventListener('click', () => {
    nav.classList.remove('active');
    body.classList.remove('active');
    filter.classList.remove('active');
})